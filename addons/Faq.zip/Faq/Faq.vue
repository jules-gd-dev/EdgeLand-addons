<template>
  <div class="bg-white py-16">
    <div class="container mx-auto px-4 max-w-3xl">
      <!-- Titre optionnel de la section -->
      <h2 v-if="data.title" class="text-3xl md:text-4xl font-bold text-center mb-12 text-base-text">
        {{ data.title }}
      </h2>

      <!-- Conteneur de l'accordéon -->
      <div class="space-y-4">
        <div 
          v-for="(item, index) in data.items" 
          :key="index"
          class="border border-gray-200 rounded-custom-card overflow-hidden"
        >
          <!-- Le bouton qui contient la question et bascule l'affichage -->
          <button 
            @click="toggleItem(index)"
            class="w-full flex justify-between items-center text-left p-6 font-semibold text-base-text hover:bg-gray-50 transition-colors"
          >
            <span>{{ item.question }}</span>
            <span 
              class="mdi mdi-chevron-down text-primary text-2xl transition-transform duration-300"
              :class="{ 'rotate-180': openItem === index }"
            ></span>
          </button>

          <!-- Le conteneur de la réponse qui s'anime -->
          <transition name="slide-faq">
            <div v-if="openItem === index">
              <div class="px-6 pb-6 text-secondary">
                <p>{{ item.answer }}</p>
              </div>
            </div>
          </transition>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';

// Interfaces pour la type-safety
interface FaqItem {
  question: string;
  answer: string;
}

interface FaqData {
  title?: string;
  items: FaqItem[];
}

defineProps({
  data: {
    type: Object as () => FaqData,
    required: true,
  }
});

// Ref pour suivre quel élément de la FAQ est actuellement ouvert
const openItem = ref<number | null>(null);

// Fonction pour ouvrir/fermer un élément
const toggleItem = (index: number) => {
  if (openItem.value === index) {
    // Si on clique sur l'élément déjà ouvert, on le ferme
    openItem.value = null;
  } else {
    // Sinon, on ouvre le nouvel élément
    openItem.value = index;
  }
};
</script>

<style scoped>
/* Transition pour l'animation de la réponse */
.slide-faq-enter-active,
.slide-faq-leave-active {
  transition: all 0.4s ease-in-out;
  max-height: 500px; /* Hauteur maximale que la réponse peut atteindre */
}

.slide-faq-enter-from,
.slide-faq-leave-to {
  max-height: 0;
  opacity: 0;
  transform: translateY(-10px);
}
</style>