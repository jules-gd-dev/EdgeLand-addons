<template>
  <figure :class="data.class">
    <img
      :src="data.src"
      :alt="data.alt"
      loading="lazy"
      decoding="async"
      class="w-full h-auto object-cover"
    />
    <figcaption v-if="data.caption" class="text-center text-sm text-gray-500 mt-2 italic">
      {{ data.caption }}
    </figcaption>
  </figure>
</template>

<script setup lang="ts">
defineProps({
  data: {
    type: Object as () => {
      src: string;        // Requis: le chemin vers l'image
      alt: string;        // Requis: le texte alternatif pour l'accessibilité
      caption?: string;   // Optionnel: la légende sous l'image
      class?: string;     // Optionnel: classes CSS pour le conteneur <figure>
    },
    required: true,
  }
});
</script>