<template>
  <section 
    class="relative min-h-[75vh] flex items-center justify-center text-center text-white bg-gray-800 bg-cover bg-center"
    :style="{ backgroundImage: data.backgroundImage ? `url(${data.backgroundImage})` : 'none' }"
  >
    <div class="absolute inset-0 bg-black/50"></div>

    <div class="relative z-10 p-8 max-w-4xl">
      <h1 v-if="data.title" class="text-4xl md:text-6xl font-extrabold tracking-tight drop-shadow-md">
        {{ data.title }}
      </h1>

      <p v-if="data.subtitle" class="mt-4 text-lg md:text-xl text-gray-200 max-w-2xl mx-auto drop-shadow">
        {{ data.subtitle }}
      </p>

      <div v-if="data.buttons && data.buttons.length" class="mt-8 flex justify-center gap-4 flex-wrap">
        <template v-for="button in data.buttons" :key="button.link">
          <router-link
            v-if="isInternalLink(button.link)"
            :to="button.link"
            :class="buttonClasses(button.variant)"
          >
            {{ button.text }}
          </router-link>
          <a
            v-else
            :href="button.link"
            target="_blank"
            rel="noopener noreferrer"
            :class="buttonClasses(button.variant)"
          >
            {{ button.text }}
          </a>
        </template>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
// Interfaces pour typer nos props, pour plus de sécurité et de clarté
interface Button {
  text: string;
  link: string;
  variant: 'primary' | 'secondary';
}

interface HeroData {
  title?: string;
  subtitle?: string;
  backgroundImage?: string;
  buttons?: Button[];
}

defineProps({
  data: {
    type: Object as () => HeroData,
    required: true,
  }
});

// Fonction pour déterminer si un lien est interne (commence par '/') ou externe
const isInternalLink = (link: string): boolean => link.startsWith('/');

// Fonction pour retourner les classes CSS en fonction de la variante du bouton
const buttonClasses = (variant: 'primary' | 'secondary' = 'primary'): string => {
  const baseClasses = "px-8 py-3 font-semibold transition-transform duration-200 ease-in-out hover:scale-105 rounded-custom-button";
  
  const variants = {
    primary: "bg-primary hover:bg-primary/90 text-white shadow-lg",
    secondary: "bg-transparent border-2 border-white hover:bg-white/10 text-white" 
  };
  
  return `${baseClasses} ${variants[variant]}`;
};

</script>