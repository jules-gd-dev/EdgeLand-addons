<template>
  <div class="bg-gray-50/50 py-16">
    <div class="container mx-auto px-4">
      <h2 v-if="data.title" class="text-3xl md:text-4xl font-bold text-center mb-16 text-base-text">
        {{ data.title }}
      </h2>
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        
        <!-- La carte est maintenant un conteneur flex vertical -->
        <div 
          v-for="(item, index) in data.items" 
          :key="index" 
          :class="cardClasses"
          :style="gridItemStyle"
        >
          <!-- 1. La zone "media" a maintenant un ratio (16:9) au lieu d'une hauteur fixe -->
          <!-- Elle s'adaptera à la largeur de la carte sans déborder. -->
          <div v-if="item.media && item.media.length > 0" class="w-full aspect-video bg-gray-100/50 flex items-center justify-center overflow-hidden">
            <ComponentRenderer :components="item.media" />
          </div>
          
          <!-- 2. La zone de contenu est séparée et gère son propre padding -->
          <div class="p-6 text-center flex-grow flex flex-col">
            <h3 class="text-xl font-bold text-primary mb-2">
              {{ item.title }}
            </h3>
            <p class="text-secondary">
              {{ item.description }}
            </p>
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed, defineAsyncComponent } from 'vue';

// L'import asynchrone est toujours correct pour éviter les dépendances circulaires
const ComponentRenderer = defineAsyncComponent(() => import('../CompomentRenderer.vue'));

// --- INTERFACES ---
interface ComponentConfig {
  type: string;
  data: any;
}

interface CardItem {
  media?: ComponentConfig[]; 
  title: string;
  description: string;
}

// 👇 MODIFICATION ICI: Ajout de cardSize à l'interface 👇
interface CardGridData {
  title?: string;
  animated?: boolean;
  cardSize?: {
    width?: string;
    height?: string;
  };
  items: CardItem[];
}

const props = defineProps({
  data: {
    type: Object as () => CardGridData,
    required: true,
  }
});

// --- Propriété Computed pour les classes ---
// Les classes de base ont été adaptées à la nouvelle structure flex
const cardClasses = computed(() => {
  // 3. Nouvelle structure de classes pour la carte : flex, vertical, et overflow caché pour les coins arrondis
  const baseClasses = 'bg-white flex flex-col rounded-custom-card shadow-lg border border-gray-100 overflow-hidden';
  const animatedClasses = 'transform hover:-translate-y-2 transition-transform duration-300';
  
  if (props.data.animated) {
    return `${baseClasses} ${animatedClasses}`;
  }
  
  return baseClasses;
});

// 👇 MODIFICATION ICI: Ajout d'une propriété computed pour les styles en ligne 👇
const gridItemStyle = computed(() => {
  const styles: { width?: string; height?: string } = {};
  const size = props.data.cardSize;

  if (size) {
    if (size.width) {
      // Applique la largeur directement. "auto" fonctionnera aussi.
      styles.width = size.width;
    }
    if (size.height) {
      // Applique la hauteur. "auto" laissera le contenu dicter la taille.
      styles.height = size.height;
    }
  }
  
  return styles;
});
</script>