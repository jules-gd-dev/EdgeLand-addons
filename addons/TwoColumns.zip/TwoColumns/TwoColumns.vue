<template>
  <div class="grid grid-cols-1 md:grid-cols-2 gap-8 my-12 container mx-auto px-4">
    
    <div>
      <ComponentRenderer :components="data.left" />
    </div>

    <div>
      <ComponentRenderer :components="data.right" />
    </div>

  </div>
</template>

<script setup lang="ts">
// On importe le renderer pour qu'il puisse afficher les enfants
import ComponentRenderer from '../CompomentRenderer.vue';

defineProps({
  data: {
    type: Object,
    required: true
  }
});
</script>