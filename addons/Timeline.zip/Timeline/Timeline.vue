<template>
  <div class="container mx-auto px-4 py-16">
    <!-- Titre optionnel de la section -->
    <h2 v-if="data.title" class="text-3xl md:text-4xl font-bold text-center mb-16 text-base-text">
      {{ data.title }}
    </h2>

    <!-- Conteneur principal de la timeline -->
    <div class="relative max-w-3xl mx-auto">
      <!-- Ligne verticale qui traverse la timeline -->
      <!-- Elle est positionnée pour être au centre de l'icône de 12 (w-12) -->
      <div class="absolute left-6 top-0 h-full w-0.5 bg-gray-200" aria-hidden="true"></div>

      <!-- Boucle sur chaque étape définie dans le YAML -->
      <div v-for="(step, index) in data.steps" :key="index" class="relative pl-16 pb-12">
        <!-- L'icône et son cercle, positionnés sur la ligne verticale -->
        <div class="absolute left-0 top-0 flex items-center justify-center w-12 h-12 bg-primary rounded-full text-white shadow-lg">
          <span :class="['mdi', step.icon, 'text-2xl']" :aria-label="step.title"></span>
        </div>

        <!-- La carte contenant le texte de l'étape -->
        <!-- On utilise la variable de thème pour l'arrondi -->
        <div class="bg-white p-6 rounded-custom-card shadow-md border border-gray-100">
          <h3 class="font-bold text-xl mb-2 text-primary">{{ step.title }}</h3>
          <p class="text-secondary">{{ step.description }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
// Interface pour typer une étape de la timeline
interface TimelineStep {
  icon: string;
  title: string;
  description: string;
}

// Interface pour les données attendues par le composant
interface TimelineData {
  title?: string;
  steps: TimelineStep[];
}

// Définition des props que le composant reçoit
defineProps({
  data: {
    type: Object as () => TimelineData,
    required: true,
  }
});
</script>