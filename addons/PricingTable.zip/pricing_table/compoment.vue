<template>
  <div class="bg-white py-16">
    <div class="container mx-auto px-4">
      <!-- Titre optionnel de la section -->
      <h2 v-if="data.title" class="text-3xl md:text-4xl font-bold text-center mb-12 text-base-text">
        {{ data.title }}
      </h2>

      <!-- Conteneur des cartes de prix -->
      <!-- Utilise flexbox pour un alignement flexible -->
      <div class="flex flex-wrap justify-center items-stretch gap-8">
        
        <!-- Boucle sur chaque plan défini dans le YAML -->
        <div 
          v-for="plan in data.plans" 
          :key="plan.name"
          class="relative flex flex-col w-full max-w-sm border rounded-[--rounding-card] shadow-lg transition-transform duration-300"
          :class="getPlanClasses(plan)"
        >
          <!-- Badge "Recommandé" -->
          <div v-if="plan.recommended" class="absolute -top-4 left-1/2 -translate-x-1/2 bg-accent text-white px-4 py-1 rounded-full text-sm font-bold shadow-md">
            Populaire
          </div>

          <!-- Contenu de la carte -->
          <div class="p-8 flex-grow flex flex-col">
            <!-- Nom et description du plan -->
            <h3 class="text-2xl font-bold text-center mb-2">{{ plan.name }}</h3>
            <p class="text-secondary text-center mb-6">{{ plan.description }}</p>
            
            <!-- Prix -->
            <div class="text-center mb-6">
              <span class="text-5xl font-extrabold text-base-text">{{ plan.price }}</span>
              <span v-if="plan.period" class="text-lg text-secondary">{{ plan.period }}</span>
            </div>

            <!-- Liste des fonctionnalités -->
            <ul class="space-y-4 text-left mb-8 flex-grow">
              <li v-for="feature in plan.features" :key="feature" class="flex items-center">
                <span class="mdi mdi-check-circle text-primary mr-3 text-xl"></span>
                <span>{{ feature }}</span>
              </li>
            </ul>

            <!-- Bouton d'action -->
            <router-link :to="plan.button.link" :class="getButtonClasses(plan)">
              {{ plan.button.text }}
            </router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
// Interfaces pour la type-safety
interface PlanButton {
  text: string;
  link: string;
}

interface Plan {
  name: string;
  price: string;
  period?: string;
  description: string;
  features: string[];
  button: PlanButton;
  recommended?: boolean;
}

interface PricingTableData {
  title?: string;
  plans: Plan[];
}

const props = defineProps({
  data: {
    type: Object as () => PricingTableData,
    required: true,
  }
});

// Fonction pour déterminer les classes de la carte
const getPlanClasses = (plan: Plan) => {
  if (plan.recommended) {
    return 'border-primary scale-105 bg-primary/5';
  }
  return 'border-gray-200 bg-white hover:-translate-y-2';
};

// Fonction pour déterminer les classes du bouton
const getButtonClasses = (plan: Plan) => {
  const base = "w-full text-center px-6 py-3 font-semibold rounded-[--rounding-button] transition-colors";
  if (plan.recommended) {
    return `${base} bg-primary text-white hover:bg-primary/90`;
  }
  return `${base} bg-gray-100 text-secondary hover:bg-gray-200`;
};
</script>