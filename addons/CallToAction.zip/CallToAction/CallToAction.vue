<template>
  <div class="bg-primary/5">
    <div class="container mx-auto px-4 py-16 text-center">
      
      <!-- Titre principal -->
      <h2 v-if="data.title" class="text-3xl md:text-4xl font-bold text-primary mb-4">
        {{ data.title }}
      </h2>

      <!-- Sous-titre ou texte descriptif -->
      <p v-if="data.subtitle" class="text-lg text-secondary max-w-2xl mx-auto mb-8">
        {{ data.subtitle }}
      </p>

      <!-- Conteneur pour les boutons -->
      <div v-if="data.buttons && data.buttons.length" class="flex justify-center gap-4 flex-wrap">
        <template v-for="button in data.buttons" :key="button.link">
          
          <!-- On utilise <router-link> pour les liens internes -->
          <router-link
            v-if="isInternalLink(button.link)"
            :to="button.link"
            :class="buttonClasses(button.style)"
          >
            {{ button.text }}
          </router-link>
          
          <!-- On utilise <a> pour les liens externes -->
          <a
            v-else
            :href="button.link"
            target="_blank"
            rel="noopener noreferrer"
            :class="buttonClasses(button.style)"
          >
            {{ button.text }}
          </a>
        </template>
      </div>

    </div>
  </div>
</template>

<script setup lang="ts">
// Interfaces pour la type-safety
interface CtaButton {
  text: string;
  link: string;
  style: 'primary' | 'secondary';
}

interface CallToActionData {
  title?: string;
  subtitle?: string;
  buttons?: CtaButton[];
}

defineProps({
  data: {
    type: Object as () => CallToActionData,
    required: true,
  }
});

// Fonction pour déterminer si un lien est interne (commence par '/') ou externe
const isInternalLink = (link: string): boolean => link.startsWith('/');

// Fonction pour retourner les classes CSS en fonction du style du bouton
const buttonClasses = (style: 'primary' | 'secondary' = 'primary'): string => {
  const baseClasses = "px-8 py-3 font-semibold transition-transform duration-200 ease-in-out hover:scale-105 rounded-custom-button text-lg";
  const styles = {
    primary: "bg-primary hover:bg-primary/90 text-white shadow-lg",
    secondary: "bg-white hover:bg-gray-50 text-primary border border-gray-200"
  };
  return `${baseClasses} ${styles[style]}`;
};
</script>