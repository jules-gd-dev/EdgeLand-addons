<template>
  <div v-html="parsedAndSanitizedHtml" class="prose lg:prose-xl max-w-none"></div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import MarkdownIt from 'markdown-it';
import DOMPurify from 'dompurify';

// MARKDOWN-IT PLUGINS
import { katex } from "@mdit/plugin-katex";
import { abbr } from "@mdit/plugin-abbr";
import { alert } from "@mdit/plugin-alert";
import { align } from "@mdit/plugin-align";
import { attrs } from "@mdit/plugin-attrs";
import { container } from "@mdit/plugin-container";
import { demo } from "@mdit/plugin-demo";
import { dl } from "@mdit/plugin-dl";
import { figure } from "@mdit/plugin-figure";
import { footnote } from "@mdit/plugin-footnote";
import { icon } from "@mdit/plugin-icon";
import { imgLazyload } from "@mdit/plugin-img-lazyload";
import { imgMark } from "@mdit/plugin-img-mark";
import { legacyImgSize } from "@mdit/plugin-img-size";
import { ins } from "@mdit/plugin-ins";
import { mark } from "@mdit/plugin-mark";
import { snippet } from "@mdit/plugin-snippet";
import { spoiler } from "@mdit/plugin-spoiler";
import { stylize } from "@mdit/plugin-stylize";
import { sub } from "@mdit/plugin-sub";
import { sup } from "@mdit/plugin-sup";
import { tab } from "@mdit/plugin-tab";
import { tasklist } from "@mdit/plugin-tasklist";

const markdownFiles = import.meta.glob('../../assets/content/*.md', { as: 'raw', eager: true });

// --- 2. On configure notre instance de markdown-it une seule fois ---
const md = new MarkdownIt()
    .use(katex)
    .use(abbr)
    .use(alert)
    .use(align)
    .use(attrs)
    .use(container, {name: "warning"})
    .use(demo)
    .use(dl)
    .use(figure)
    .use(footnote)
    .use(icon)
    .use(imgLazyload)
    .use(imgMark)
    .use(legacyImgSize)
    .use(ins)
    .use(mark)
    .use(snippet, {currentPath: (env) => env.filePath})
    .use(spoiler)
    .use(stylize)
    .use(sub)
    .use(sup)
    .use(tab)
    .use(tasklist);

const props = defineProps({
    data: {
        type: Object as () => { file: string },
        required: true,
    }
});

// --- 3. La logique devient SYNCHRONE et beaucoup plus simple ! ---
// Plus besoin de "watch" ou de "ref" pour le contenu.
const parsedAndSanitizedHtml = computed(() => {
    // On construit la clé pour retrouver le fichier dans notre objet
    const path = `../../assets/content/${props.data.file}`;

    const rawContent = markdownFiles[path];

    if (!rawContent) {
        console.error(`Le fichier Markdown n'a pas été trouvé dans le glob : ${path}`);
        const errorHtml = md.render(`## Erreur\n\nFichier non trouvé: \`${props.data.file}\``);
        return DOMPurify.sanitize(errorHtml);
    }

    const rawHtml = md.render(rawContent);
    return DOMPurify.sanitize(rawHtml);
});
</script>
