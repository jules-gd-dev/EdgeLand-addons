<template>
  <!-- Le conteneur qui affichera le diagramme, centré via flexbox. -->
  <div ref="container" class="w-full h-full flex items-center justify-center diagram-container"></div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, computed } from 'vue';
import mermaid from 'mermaid';

// --- NOUVELLES INTERFACES POUR LE YAML STRUCTURÉ ---
interface DiagramNode {
  id: string;
  text: string;
  shape?: 'default' | 'round-edges' | 'stadium' | 'diamond';
}

interface DiagramLink {
  from: string;
  to: string;
  label?: string;
}

interface DiagramData {
  direction?: 'TD' | 'LR'; // Top-Down, Left-Right
  nodes: DiagramNode[];
  links: DiagramLink[];
}

const props = defineProps({
  data: {
    type: Object as () => DiagramData,
    required: true,
  }
});

const container = ref<HTMLElement | null>(null);

// --- NOUVELLE LOGIQUE : Traduction de YAML en code Mermaid ---
const mermaidCode = computed(() => {
  if (!props.data || !props.data.nodes || !props.data.links) {
    return ''; 
  }

  const { direction = 'TD', nodes, links } = props.data;
  const shapeMap = {
    'default': ['[', ']'], 'round-edges': ['(', ')'], 'stadium': ['([', '])'], 'diamond': ['{', '}']
  };

  const nodeLines = nodes.map(node => {
    const [start, end] = shapeMap[node.shape || 'default'];
    const sanitizedText = node.text.replace(/"/g, '#quot;');
    return `  ${node.id}${start}"${sanitizedText}"${end}`;
  }).join('\n');

  const linkLines = links.map(link => {
    return link.label ? `  ${link.from} -- "${link.label}" --> ${link.to}` : `  ${link.from} --> ${link.to}`;
  }).join('\n');

  return `graph ${direction}\n${nodeLines}\n${linkLines}`;
});

// --- MOTEUR DE RENDU (logique similaire mais utilise mermaidCode) ---
const renderDiagram = async () => {
  if (!container.value || !mermaidCode.value) {
    if (container.value) {
        container.value.innerHTML = `<div class="text-red-500 text-xs text-center p-2 w-full h-full flex items-center justify-center border border-dashed border-red-300 rounded-md">Données du diagramme invalides ou vides.</div>`;
    }
    return;
  }
  
  try {
    const uniqueId = `mermaid-${Math.random().toString(36).substring(2, 9)}`;
    const { svg } = await mermaid.render(uniqueId, mermaidCode.value);
    
    // ✅ LA CORRECTION : On supprime les attributs de taille du SVG
    // pour le forcer à s'adapter à la taille de son conteneur CSS.
    const fluidSvg = svg.replace(/height=".*?"/, '').replace(/width=".*?"/, '');
    
    container.value.innerHTML = fluidSvg;

  } catch (error) {
    console.error("[Diagram.vue] Erreur lors du rendu Mermaid :", error);
    container.value.innerHTML = `<p class="text-red-500 text-xs text-center p-2">Erreur dans la syntaxe du diagramme généré. Vérifiez la console.</p>`;
  }
};

// --- Cycle de vie ---
mermaid.initialize({ startOnLoad: false, theme: 'neutral', securityLevel: 'loose' });
onMounted(renderDiagram);
watch(mermaidCode, renderDiagram);
</script>

<style>
/* Style pour s'assurer que le SVG s'adapte bien et conserve ses proportions */
.diagram-container svg {
  width: 100%;
  height: 100%;
  max-width: 100%;
  max-height: 100%;
  object-fit: contain; /* Assure que le diagramme entier est visible */
}
</style>
